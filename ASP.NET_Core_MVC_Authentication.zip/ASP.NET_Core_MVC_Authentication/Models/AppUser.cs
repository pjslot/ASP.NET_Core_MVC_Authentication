﻿//класс идентифицируемого пользователя
using Microsoft.AspNetCore.Identity;

namespace ASP.NET_Core_MVC_Authentication.Models
{
    public class AppUser : IdentityUser
    {
        //public string Country;
        //public string City;
    }
}
